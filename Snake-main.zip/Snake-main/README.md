# Snake
A simple snake game written in C# Console Application.  

Requires .NET 7.0 to build/run.  

## Control
Change terminal window size to resize game map.  

**Enter**: Start the game  
**Arrow keys (←↑→↓)**: Change snake moving direction  

## Screenshot
![snake](img/snake.webp)